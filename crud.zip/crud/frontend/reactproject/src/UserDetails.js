import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import axios from "axios";

function UserDetails() {
  const { id } = useParams();
  const [user, setUser] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    axios.get(`http://localhost:3001/users/${id}`)
      .then(res => setUser(res.data))
      .catch(err => setError("Erro ao carregar usuário."));
  }, [id]);

  if (error) return <div className="text-red-500">{error}</div>;
  if (!user) return <div>Carregando...</div>;

  return (
    <div className="p-4 bg-white rounded shadow">
      <h2 className="text-2xl font-bold mb-2">Detalhes do Usuário</h2>
      <p><strong>ID:</strong> {user.id}</p>
      <p><strong>Nome:</strong> {user.nome}</p>
      <p><strong>Email:</strong> {user.email}</p>
      <Link to="/" className="text-blue-500 underline">Voltar</Link>
    </div>
  );
}

export default UserDetails;
