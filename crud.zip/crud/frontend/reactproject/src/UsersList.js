import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";

function UsersList() {
    const [users, setUsers] = useState([]);
    const [error, setError] = useState("");

    useEffect(() => {
        axios.get("http://localhost:9090/users")
            .then((res) => {
                setUsers(res.data);
                setError("");
            })
            .catch((err) => {
                console.error(err);
                setError("Erro ao carregar usuários.");
            });
    }, []);

    const handleDelete = (id) => {
        if (window.confirm("Tem certeza que deseja excluir este usuário?")) {
            axios.delete(`http://localhost:9090/users/${id}`)
                .then(() => {
                    setUsers(users.filter(user => user.id !== id));
                })
                .catch((err) => {
                    console.error(err);
                    alert("Erro ao excluir usuário.");
                });
        }
    };

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold mb-4">Lista de Usuários</h2>

            {error && <div className="text-red-600 mb-4">{error}</div>}

            <Link 
                to="/create" 
                className="novo-usuario mb-6"
            >
                Novo Usuário
            </Link>



            <table className="w-full border-collapse">
                <thead>
                    <tr className="bg-gray-200 text-left">
                        <th className="p-3 border">ID</th>
                        <th className="p-3 border">Nome</th>
                        <th className="p-3 border">Email</th>
                        <th className="p-3 border">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map((user) => (
                        <tr key={user.id} className="border-b hover:bg-gray-50">
                            <td className="p-3 border">{user.id}</td>
                            <td className="p-3 border">{user.nome}</td>
                            <td className="p-3 border">{user.email}</td>
                            <td className="p-3 border space-x-2">
                                <Link to={`/edit/${user.id}`} className="bg-yellow-400 text-white px-3 py-1 rounded hover:bg-yellow-500">
                                    Editar
                                </Link>
                                <button
                                    onClick={() => handleDelete(user.id)}
                                    className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
                                >
                                    Excluir
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default UsersList;
