import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import axios from "axios"; // ou: import api from './api'; se quiser usar a dica extra

function EditUser() {
    const { id } = useParams();
    const [nome, setNome] = useState("");
    const [email, setEmail] = useState("");
    const [pswd, setPswd] = useState("");
    const navigate = useNavigate();

    useEffect(() => {
        axios
            .get(`http://localhost:9090/users/${id}`)
            .then((res) => {
                setNome(res.data.nome);
                setEmail(res.data.email);
            })
            .catch((err) => {
                console.error("Erro ao buscar usuário:", err);
                alert("Erro ao buscar os dados do usuário.");
            });
    }, [id]);

    const handleSubmit = (e) => {
        e.preventDefault();
        axios
            .put(`http://localhost:9090/users/${id}`, { nome, email, pswd })
            .then(() => {
                alert("Usuário atualizado com sucesso!");
                navigate("/");
            })
            .catch((err) => {
                console.error("Erro ao atualizar usuário:", err);
                alert("Erro ao atualizar o usuário.");
            });
    };

    return (
        <form onSubmit={handleSubmit}>
            <input
                type="text"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                placeholder="Nome"
                required
            />
            <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                required
            />
            <input
                type="password"
                placeholder="Nova senha"
                onChange={(e) => setPswd(e.target.value)}
            />
            <button type="submit">Atualizar</button>
        </form>
    );
}

export default EditUser;
